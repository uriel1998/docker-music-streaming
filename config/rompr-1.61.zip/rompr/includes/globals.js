var sources = new Array();
var last_selected_element = null;
var resizeTimer = null;
const masonry_gutter = 8;
var coverscraper;
var lastfm;
var albumart_update = true;
