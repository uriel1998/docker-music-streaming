<?php

chdir('../..');
readfile('prefs/canmonitor');

?>
