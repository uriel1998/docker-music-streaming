<?php

$results = array();
$results['time'] = time();
print json_encode($results);

?>
