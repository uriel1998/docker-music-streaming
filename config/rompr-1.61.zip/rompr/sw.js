self.addEventListener('install', function(e) {

    // This is a dummy function because Chrome needs a service worker
    // for Add To Home Screen to work

});
